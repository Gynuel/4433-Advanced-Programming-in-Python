# Pytest 

Pytest is a framework for writting tests in Python. This project contains small examples of writting tests. 
Pytest runs functions that start with `test_` in all files of the form `test_*.py` or `*_test.py` in the current directory and subdirectories.

