def capitalcase(x: str):
    return x.capitalize()

def uppercase(x: str):
    return x.upper()

#def lowercase(x: str):
#    return x

def division(a, b):
    return a/b
    
def operations(a,b):
    return a - b

#print(capitalcase(1))
print(capitalcase("python"))
print(uppercase("python"))
#print(lowercase("Python"))
print(division(10,5))
print(operations(30,10))