import pytest
from yourcode import capitalcase,uppercase,division,operations#,lowercase

def test_capitalcase():
    assert capitalcase("python") == "Python"
# assert will verify if the expected result of your function is matching the result of your test

def test_uppercase():
    assert uppercase("python") == "PYTHON"

#def test_lowercase():
#    assert lowercase("Python") == "python"
#lower case function is wrong, is returning the input string without calling the lower case function

#you can also test if a function raises an exception as expected
def test_division():
    with pytest.raises(ZeroDivisionError):
        division(10,0)

#or if you want to test the same function but with different parameters, you can use the mark.parametrize annotation
@pytest.mark.parametrize("a,b,c", [
    (30, 10, 20),
    (20, 2, 18),
])
def test_operations(a, b, c):
    assert operations(a,b) == c